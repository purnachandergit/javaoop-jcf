package com.visa.fundraiser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FundraiserApplication {

	public static void main(String[] args) {
		SpringApplication.run(FundraiserApplication.class, args);
	}

}
